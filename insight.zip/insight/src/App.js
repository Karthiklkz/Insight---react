import { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.css";

export default function App() {
  const [insight, setInsight] = useState();
  const [count, setCount] = useState(0);

  async function getInsight() {
    const res = await fetch("https://api.adviceslip.com/advice");
    const data = await res.json();
    setInsight(data.slip.advice);
    setCount((c) => c + 1);
  }

  useEffect(function () {
    getInsight();
  }, []);

  return (
    <div className="container-fluid bg-dark d-flex justify-content-center align-items-center vh-100">
      <div
        className="card shadow"
        style={{
          width: "28rem",
          backgroundColor: "#222", // Dark card background
          color: "#e0e0e0", // Light grey text for better contrast
        }}
      >
        <div className="card-body text-center">
          <h5 className="card-title text-info">Insight of the Day</h5>
          <p
            className="card-text fw-bold"
            style={{ fontSize: "1.3rem", color: "#f8d64e" }} // Golden yellow for the insight text
          >
            {insight || "Fetching a brilliant thought..."}
          </p>
          <button
            className="btn btn-outline-warning btn-lg my-3"
            onClick={getInsight}
          >
            Get Another Insight
          </button>
          <p className="text-light" style={{ color: "white" }}>
            Insights fetched: <strong>{count}</strong> times
          </p>
        </div>
      </div>
    </div>
  );
}
